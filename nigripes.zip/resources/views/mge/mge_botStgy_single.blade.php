@extends('layouts.app')

@section('content')
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title">
                
            </div>
            <h4 class="page-title">
                @if( is_null($botStgy) )
                新增策略
                @else
                編輯策略
                @endif
            </h4>
        </div>
    </div>
</div>     
<!-- end page title --> 
<div class="row">
    <div class="col-lg-6">
        <div class="card-box">
            <div class="card">
                <div class="card-body">
                    
                    <form class="form-horizontal" role="form" method="POST" enctype="multipart/form-data" action="
                    @if( is_null($botStgy) )
                    {{ URL::to('mge/botStgys/add')}}
                    @else
                    {{ URL::to('mge/botStgys')}}/{{ $botStgy->id }}
                    @endif
                    ">
                    @csrf

                        <div class="mb-3">
                            <label for="title" class="col-3 col-form-label">策略名稱<span class="text-danger">*</span></label>
                            <div class="col-12">
                                <input type="text" class="form-control" id="stgyName" name="stgyName" value="@if(!is_null($botStgy)){{ $botStgy->stgyName }}@endif" required >
                                                            
                                @error('stgyName')
                                <span role="alert" style="color: red;">
                                    {{ $message }}
                                </span>
                                @enderror
                                
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="stgyMapfun" class="col-3 col-form-label">策略Function<span class="text-danger">*</span></label>
                            <div class="col-12">
                                <input type="text" class="form-control" id="stgyMapfun" name="stgyMapfun" value="@if(!is_null($botStgy)){{ $botStgy->stgyMapfun }}@endif" required >
                                                            
                                @error('stgyMapfun')
                                <span role="alert" style="color: red;">
                                    {{ $message }}
                                </span>
                                @enderror

                                <span role="alert" style="color: black;">
                                    請確認於程式中已新增該項策略相關程式
                                </span>
                                
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="notice" class="col-3 col-form-label">策略說明</label>
                            <div class="col-12">
                                <input type="text" class="form-control" id="notice" name="notice" value="@if(!is_null($botStgy)){{ $botStgy->notice }}@endif" >
                                                            
                                @error('notice')
                                <span role="alert" style="color: red;">
                                    {{ $message }}
                                </span>
                                @enderror
                                
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="reBuyPer" class="col-3 col-form-label">反彈買入百分比</label>
                            <div class="col-12">
                                <input type="text" class="form-control" id="reBuyPer" name="reBuyPer" value="@if(!is_null($botStgy)){{ $botStgy->reBuyPer }}@endif" required >
                                                            
                                @error('reBuyPer')
                                <span role="alert" style="color: red;">
                                    {{ $message }}
                                </span>
                                @enderror
                                
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="reSellPer" class="col-3 col-form-label">反彈賣出百分比</label>
                            <div class="col-12">
                                <input type="text" class="form-control" id="reSellPer" name="reSellPer" value="@if(!is_null($botStgy)){{ $botStgy->reSellPer }}@endif" required >
                                                            
                                @error('reSellPer')
                                <span role="alert" style="color: red;">
                                    {{ $message }}
                                </span>
                                @enderror
                                
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="maxDCAqty" class="col-3 col-form-label">最大DCA次數</label>
                            <div class="col-12">
                                <input type="text" class="form-control" id="maxDCAqty" name="maxDCAqty" value="@if(!is_null($botStgy)){{ $botStgy->maxDCAqty }}@endif" required >
                                                            
                                @error('maxDCAqty')
                                <span role="alert" style="color: red;">
                                    {{ $message }}
                                </span>
                                @enderror
                                
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="status" class="col-3 col-form-label">狀態</label>
                            <div class="col-12">
                                <select id="sstatus" name="sstatus" class="form-control">
                                    <option value="0" @if(!is_null($botStgy) && $botStgy->status == "0" ) selected @endif>啟用</option>
                                    <option value="1" @if( is_null($botStgy) | (!is_null($botStgy) && $botStgy->status == "1") ) selected @endif>停用</option>
                                </select>
                                                            
                                @error('status')
                                <span role="alert" style="color: red;">
                                    {{ $message }}
                                </span>
                                @enderror
                                
                            </div>
                        </div>

                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-blue waves-effect waves-light">儲存</button>
                            <button type="button"" class="btn btn-secondary waves-effect" onclick="window.location='{{ url("mge/botStgys" )}}'">返回</button>
                        </div>
                        
                    </form>

                </div> <!-- end card-body -->
            </div>
        </div>
    </div>
</div>

@endsection