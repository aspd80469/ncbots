<?php

namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;

class SysLog extends Authenticatable
{
    // protected $table = 'managers';

    protected $fillable = [
    ];


}
