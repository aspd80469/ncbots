<?php

namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;

class UserKey extends Authenticatable
{
    // protected $table = 'managers';

    protected $fillable = [
    ];


}
