<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title">
                
            </div>
            <h4 class="page-title">系統紀錄 &nbsp; &nbsp;
            </h4>
        </div>
    </div>
</div>     
<!-- end page title --> 

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <div class="table-responsive">
                    <table class="table table-centered mb-0">
                        <thead class="thead-light">
                            <tr>
                                <th>#</th>
								<th>時間</th>
                                <th>類型</th>
                                <th>動作</th>
								<th>內容</th>
                                <th>使用者</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sysLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sysLog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                  <?php echo e($sysLog->id); ?>

                                </td>
                                <td>
									<?php echo e($sysLog->created_at); ?>

                                </td>
								<td>
									<?php echo e($sysLog->type); ?>

                                </td>
                                <td>
									<?php echo e($sysLog->operation); ?>

                                </td>
								<td>
									<?php echo e($sysLog->msg); ?>

                                </td>
                                <td>
									<?php echo e($sysLog->userid); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="pagination pagination-rounded justify-content-end my-2">
                    <?php echo e($sysLogs->appends(Request::except('page'))->links()); ?>

                </div>

                <style>
                    nav {
                        overflow: scroll !important;
                    }
                </style>
                
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col -->
</div>
<!-- end row -->
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nigripes\resources\views/mge/mge_sysLogs.blade.php ENDPATH**/ ?>