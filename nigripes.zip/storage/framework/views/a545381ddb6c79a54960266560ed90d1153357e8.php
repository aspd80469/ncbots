<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title">
                
            </div>
            <h4 class="page-title">方案管理 &nbsp; &nbsp;
                  <button type="button" class="btn btn-blue waves-effect waves-light" onclick="window.location='<?php echo e(url('mge/userPlan')); ?>'">建立方案</button>
            </h4>
        </div>
    </div>
</div>     
<!-- end page title --> 

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <div class="table-responsive">
                    <table class="table table-centered mb-0">
                        <thead class="thead-light">
                            <tr>
                                <th>#</th>
								<th>方案名稱</th>
                                <th>最大下單量</th>
                                <th>Api數量</th>
                                <th>付款週期</th>
                                <th>費用</th>
                                <th>啟用</th>
                                <th>建立日期</th>
                                <th>管理</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $userPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userPlan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                  <?php echo e($userPlan->id); ?>

                                </td>
                                <td>
                                    <?php echo e($userPlan->planName); ?>

                                </td>
                                <td>
                                    <?php echo e($userPlan->maxOrders); ?>

                                </td>
                                <td>
                                    <?php echo e($userPlan->maxApiSlot); ?>

                                </td>
                                <td>
                                    <?php echo e($userPlan->payPeriod); ?>

                                </td>
                                <td>
                                    <?php echo e($userPlan->fee); ?>

                                </td>
                                <td>
                                    <?php echo e($userPlan->enabled); ?>

                                </td>
                                <td>
                                    <?php echo e($userPlan->created_at); ?>

                                </td>
                                <td>
                                    <button type="submit" class="btn btn-blue waves-effect waves-light" onclick="window.location='<?php echo e(url("mge/userPlans/" . $userPlan->id )); ?>'">編輯</button>
                                    <button type="submit" class="btn btn-danger waves-effect waves-light" onclick="window.location='<?php echo e(url("mge/userPlans/delete/" . $userPlan->id  )); ?>'">刪除</button>
                                  </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="pagination pagination-rounded justify-content-end my-2">
                    <?php echo e($userPlans->appends(Request::except('page'))->links()); ?>

                </div>

                <style>
                    nav {
                        overflow: scroll !important;
                    }
                </style>
                
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col -->
</div>
<!-- end row -->
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nigripes\resources\views/mge/mge_userPlan.blade.php ENDPATH**/ ?>