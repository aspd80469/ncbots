<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title">
                
            </div>
            <h4 class="page-title">
                API Key 設定 &nbsp; &nbsp;
                <button type="button" class="btn btn-blue waves-effect waves-light" onclick="window.location='<?php echo e(url('/apiSettings/0')); ?>'"><i class="fas fa-plus"></i> 新增API Key</button>
            </h4>
        </div>
    </div>
</div>     
<!-- end page title --> 

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <div class="table-responsive">
                    <table class="table table-centered mb-0">
                        <thead class="thead-light">
                            <tr>
								<th>交易所</th>
                                <th>API Key</th>
                                <th>備註</th>
                                <th>狀態</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $apiSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apiSetting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(url("/apiSettings/" . $apiSetting->id )); ?>">
                                    <?php if( $apiSetting->exchange == "binance"): ?>
                                    Binance
                                    <?php elseif( $apiSetting->exchange == "ftx"): ?>
                                    FTX
                                    <?php elseif( $apiSetting->exchange == "bybit"): ?>
                                    ByBit
                                    <?php endif; ?>
                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(url("/apiSettings/" . $apiSetting->id )); ?>">
                                    <?php echo e($apiSetting->apikey); ?>

                                    </a>
                                </td>
                                    <a href="<?php echo e(url("/apiSettings/" . $apiSetting->id )); ?>">
                                    <?php echo e($apiSetting->notice); ?>

                                    </a>
                                <td>
                                    <a href="<?php echo e(url("/apiSettings/" . $apiSetting->id )); ?>">
                                    <?php echo e($apiSetting->id); ?>

                                    </a>
                                </td>
                                
                                <td>
                                    <?php if( $apiSetting->botUsed == 0 ): ?>
                                    閒置中
                                    <?php else: ?>
                                    已使用
                                    <?php endif; ?>
                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="pagination pagination-rounded justify-content-end my-2">
                    <?php echo e($apiSettings->appends(Request::except('page'))->links()); ?>

                </div>

                <style>
                    nav {
                        overflow: scroll !important;
                    }
                </style>
                
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col -->
</div>
<!-- end row -->
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nigripes\resources\views/apiSettings.blade.php ENDPATH**/ ?>