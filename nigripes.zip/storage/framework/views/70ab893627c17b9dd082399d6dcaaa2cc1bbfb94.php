<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title">
                
            </div>
            <h4 class="page-title">參數設定 &nbsp; &nbsp;
            <button type="button" class="btn btn-blue waves-effect waves-light" onclick="window.location='<?php echo e(url('mge/settings/add')); ?>'"><i class="fas fa-plus"></i> 新增參數</button>
            </h4>
        </div>
    </div>
</div>     
<!-- end page title --> 

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <div class="table-responsive">
                    <table class="table table-centered mb-0">
                        <thead class="thead-light">
                            <tr>
                                <th>參數</th>
                                <th>描述</th>
                                <th>設定值</th>
                                <th>管理</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                  <?php echo e($setting->name); ?>

                                </td>
                                <td>
                                    <?php echo e($setting->sdesc); ?>

                                  </td>
                                <td>
                                    <textarea class="form-control" readonly="readonly"><?php echo e($setting->value); ?></textarea>
                                  </td>
                                <td>
                                    <button type="submit" class="btn btn-blue waves-effect waves-light" onclick="window.location='<?php echo e(url("mge/settings/" . $setting->id )); ?>'">編輯</button>
                                  </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="pagination pagination-rounded justify-content-end my-2">
                    <?php echo e($settings->appends(Request::except('page'))->links()); ?>

                </div>

                <style>
                    nav {
                        overflow: scroll !important;
                    }
                </style>
                
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col -->
</div>
<!-- end row -->
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nigripes\resources\views/mge/mge_settings.blade.php ENDPATH**/ ?>