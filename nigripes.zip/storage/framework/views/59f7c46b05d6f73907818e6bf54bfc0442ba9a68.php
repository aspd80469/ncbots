<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title">
                
            </div>
            <h4 class="page-title">訊號Token &nbsp; &nbsp;
                  <button type="button" class="btn btn-blue waves-effect waves-light" onclick="window.location='<?php echo e(url('mge/sysSignals/add')); ?>'"><i class="fas fa-plus"></i> 新增Token</button>
            </h4>
        </div>
    </div>
</div>     
<!-- end page title --> 

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <div class="table-responsive">
                    <table class="table table-centered mb-0">
                        <thead class="thead-light">
                            <tr>
                                <th>Token</th>
                                <th>描述</th>
                                <th>管理</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sysSignals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sysSignal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                  <?php echo e($sysSignal->ncToken); ?>

                                </td>
                                <td>
                                    <?php echo e($sysSignal->tdsec); ?>

                                </td>
                                <td>
                                    <button type="submit" class="btn btn-blue waves-effect waves-light" onclick="window.location='<?php echo e(url("mge/sysSignals/" . $sysSignal->id )); ?>'">編輯</button>
                                  </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="pagination pagination-rounded justify-content-end my-2">
                    <?php echo e($sysSignals->appends(Request::except('page'))->links()); ?>

                </div>

                <style>
                    nav {
                        overflow: scroll !important;
                    }
                </style>
                
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col -->
</div>
<!-- end row -->
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nigripes\resources\views/mge/mge_sysSignals.blade.php ENDPATH**/ ?>