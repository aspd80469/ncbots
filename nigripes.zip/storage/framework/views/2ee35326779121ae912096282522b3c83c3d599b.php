<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title">
                
            </div>
            <h4 class="page-title">
                <?php if( is_null($botStgy) ): ?>
                新增策略
                <?php else: ?>
                編輯策略
                <?php endif; ?>
            </h4>
        </div>
    </div>
</div>     
<!-- end page title --> 
<div class="row">
    <div class="col-lg-6">
        <div class="card-box">
            <div class="card">
                <div class="card-body">
                    
                    <form class="form-horizontal" role="form" method="POST" enctype="multipart/form-data" action="
                    <?php if( is_null($botStgy) ): ?>
                    <?php echo e(URL::to('mge/botStgys/add')); ?>

                    <?php else: ?>
                    <?php echo e(URL::to('mge/botStgys')); ?>/<?php echo e($botStgy->id); ?>

                    <?php endif; ?>
                    ">
                    <?php echo csrf_field(); ?>

                        <div class="mb-3">
                            <label for="title" class="col-3 col-form-label">策略名稱<span class="text-danger">*</span></label>
                            <div class="col-12">
                                <input type="text" class="form-control" id="stgyName" name="stgyName" value="<?php if(!is_null($botStgy)): ?><?php echo e($botStgy->stgyName); ?><?php endif; ?>" required >
                                                            
                                <?php $__errorArgs = ['stgyName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span role="alert" style="color: red;">
                                    <?php echo e($message); ?>

                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="stgyMapfun" class="col-3 col-form-label">策略Function<span class="text-danger">*</span></label>
                            <div class="col-12">
                                <input type="text" class="form-control" id="stgyMapfun" name="stgyMapfun" value="<?php if(!is_null($botStgy)): ?><?php echo e($botStgy->stgyMapfun); ?><?php endif; ?>" required >
                                                            
                                <?php $__errorArgs = ['stgyMapfun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span role="alert" style="color: red;">
                                    <?php echo e($message); ?>

                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <span role="alert" style="color: black;">
                                    請確認於程式中已新增該項策略相關程式
                                </span>
                                
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="notice" class="col-3 col-form-label">策略說明</label>
                            <div class="col-12">
                                <input type="text" class="form-control" id="notice" name="notice" value="<?php if(!is_null($botStgy)): ?><?php echo e($botStgy->notice); ?><?php endif; ?>" >
                                                            
                                <?php $__errorArgs = ['notice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span role="alert" style="color: red;">
                                    <?php echo e($message); ?>

                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="reBuyPer" class="col-3 col-form-label">反彈買入百分比</label>
                            <div class="col-12">
                                <input type="text" class="form-control" id="reBuyPer" name="reBuyPer" value="<?php if(!is_null($botStgy)): ?><?php echo e($botStgy->reBuyPer); ?><?php endif; ?>" required >
                                                            
                                <?php $__errorArgs = ['reBuyPer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span role="alert" style="color: red;">
                                    <?php echo e($message); ?>

                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="reSellPer" class="col-3 col-form-label">反彈賣出百分比</label>
                            <div class="col-12">
                                <input type="text" class="form-control" id="reSellPer" name="reSellPer" value="<?php if(!is_null($botStgy)): ?><?php echo e($botStgy->reSellPer); ?><?php endif; ?>" required >
                                                            
                                <?php $__errorArgs = ['reSellPer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span role="alert" style="color: red;">
                                    <?php echo e($message); ?>

                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="maxDCAqty" class="col-3 col-form-label">最大DCA次數</label>
                            <div class="col-12">
                                <input type="text" class="form-control" id="maxDCAqty" name="maxDCAqty" value="<?php if(!is_null($botStgy)): ?><?php echo e($botStgy->maxDCAqty); ?><?php endif; ?>" required >
                                                            
                                <?php $__errorArgs = ['maxDCAqty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span role="alert" style="color: red;">
                                    <?php echo e($message); ?>

                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="status" class="col-3 col-form-label">狀態</label>
                            <div class="col-12">
                                <select id="sstatus" name="sstatus" class="form-control">
                                    <option value="0" <?php if(!is_null($botStgy) && $botStgy->status == "0" ): ?> selected <?php endif; ?>>啟用</option>
                                    <option value="1" <?php if( is_null($botStgy) | (!is_null($botStgy) && $botStgy->status == "1") ): ?> selected <?php endif; ?>>停用</option>
                                </select>
                                                            
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span role="alert" style="color: red;">
                                    <?php echo e($message); ?>

                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                            </div>
                        </div>

                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-blue waves-effect waves-light">儲存</button>
                            <button type="button"" class="btn btn-secondary waves-effect" onclick="window.location='<?php echo e(url("mge/botStgys" )); ?>'">返回</button>
                        </div>
                        
                    </form>

                </div> <!-- end card-body -->
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nigripes\resources\views/mge/mge_botStgy_single.blade.php ENDPATH**/ ?>