<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title">
                
            </div>
            <h4 class="page-title">
                <?php if( is_null($userPlan) ): ?>
                建立方案
                <?php else: ?>
                編輯方案
                <?php endif; ?>
            </h4>
        </div>
    </div>
</div>     
<!-- end page title --> 
<div class="row">
    <div class="col-lg-6">
        <div class="card-box">
            <div class="card">
                <div class="card-body">

                    <form class="form-horizontal" role="form" method="POST" enctype="multipart/form-data" action="
					<?php if( is_null($userPlan) ): ?>
					<?php echo e(URL::to('mge/userPlan')); ?>

					<?php else: ?>
					<?php echo e(URL::to('mge/userPlan')); ?>/<?php echo e($userPlan->id); ?>

					<?php endif; ?>
					">
					<?php echo csrf_field(); ?>

                        <div class="mb-3">
                            <label for="planName" class="form-label">方案名稱</label>
                            <input type="text" id="planName" name="planName" class="form-control" placeholder="" value="<?php if( !is_null($userPlan) ): ?><?php echo e($userPlan->planName); ?><?php endif; ?>">
							
							<?php if( $errors->has('planName') ): ?>
							<span class="help-block">
							<strong>必填，最大長度為20字元</strong>
							</span>
							<?php endif; ?>
					
                        </div>

                        <div class="mb-3">
                            <label for="maxOrders" class="form-label">最大下單量</label>
                            <input type="text" id="maxOrders" name="maxOrders" class="form-control" placeholder="" value="<?php if( !is_null($userPlan) ): ?><?php echo e($userPlan->maxOrders); ?><?php endif; ?>">
							
							<?php if( $errors->has('maxOrders') ): ?>
							<span class="help-block">
							<strong>必填</strong>
							</span>
							<?php endif; ?>
					
                        </div>

                        <div class="mb-3">
                            <label for="maxApiSlot" class="form-label">Api數量</label>
                            <input type="text" id="maxApiSlot" name="maxApiSlot" class="form-control" placeholder="" value="<?php if( !is_null($userPlan) ): ?><?php echo e($userPlan->maxApiSlot); ?><?php endif; ?>">
							
							<?php if( $errors->has('maxApiSlot') ): ?>
							<span class="help-block">
							<strong>必填</strong>
							</span>
							<?php endif; ?>
					
                        </div>

                        <div class="mb-3">
                            <label for="payPeriod" class="form-label">付款週期</label>
                            <input type="text" id="payPeriod" name="payPeriod" class="form-control" placeholder="" value="<?php if( !is_null($userPlan) ): ?><?php echo e($userPlan->payPeriod); ?><?php endif; ?>">
							
							<?php if( $errors->has('payPeriod') ): ?>
							<span class="help-block">
							<strong>必填</strong>
							</span>
							<?php endif; ?>
					
                        </div>

                        <div class="mb-3">
                            <label for="fee" class="form-label">費用</label>
                            <input type="text" id="fee" name="fee" class="form-control" placeholder="" value="<?php if( !is_null($userPlan) ): ?><?php echo e($userPlan->fee); ?><?php endif; ?>">
							
							<?php if( $errors->has('fee') ): ?>
							<span class="help-block">
							<strong>必填</strong>
							</span>
							<?php endif; ?>
					
                        </div>
						
						<div class="mb-3">
						
                            <label for="fee" class="form-label">啟用</label>
							<select class="form-control" name="enabled">
								<option value="0" <?php if( !is_null($userPlan) && $userPlan->enabled == '0' ): ?> selected <?php endif; ?>>啟用</option>
								<option value="1" <?php if( !is_null($userPlan) && $userPlan->enabled == '1' ): ?> selected <?php endif; ?>>停用</option>
							</select>
							
							<?php if( $errors->has('enabled') ): ?>
							<span class="help-block">
							<strong>必填，必須選擇一個選項</strong>
							</span>
							<?php endif; ?>
					
                        </div>

                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-blue waves-effect waves-light">儲存</button>
                            <button type="button"" class="btn btn-secondary waves-effect" onclick="window.location='<?php echo e(url("mge/userPlans" )); ?>'">返回</button>
							
							<?php if( !is_null($userPlan) ): ?>
							<a href="<?php echo e(url("mge/userPlan/delete/" . $userPlan->id )); ?>" onclick="javascript:return confirm('確認刪除方案?');" class="btn btn-danger waves-effect">刪除</a>
							<?php endif; ?>
				
                        </div>
                        
                    </form>
                </div> <!-- end card-body -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nigripes\resources\views/mge/mge_userPlan_single.blade.php ENDPATH**/ ?>