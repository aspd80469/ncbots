<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title">
                
            </div>
            <h4 class="page-title">訊號紀錄 &nbsp; &nbsp;
            </h4>
        </div>
    </div>
</div>     
<!-- end page title --> 

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="row g-13">
                    <div class="col-lg-12">
                        <form class="row g-3" role="form" method="POST" enctype="multipart/form-data" action="<?php echo e(url('mge/sysSignalLog')); ?>">
                            <?php echo csrf_field(); ?>
							<div class="col-xl-2 col-md-3">
                                <label for="timeFrame-select" class="mr-2">時框</label>
								<select class="form-control" name="timeFrame">
									<option value="15m" <?php if( old('timeFrame') == '15m' ): ?> selected <?php endif; ?>>15M</option>
									<option value="30m" <?php if( old('timeFrame') == '30m' ): ?> selected <?php endif; ?>>30M</option>
									<option value="1h" <?php if( old('timeFrame') == '1h' ): ?> selected <?php endif; ?>>1H</option>
									<option value="4h" <?php if( old('timeFrame') == '4h' ): ?> selected <?php endif; ?>>4H</option>
									<option value="12h" <?php if( old('timeFrame') == '12h' ): ?> selected <?php endif; ?>>12H</option>
									<option value="day" <?php if( old('timeFrame') == 'day' ): ?> selected <?php endif; ?>>天</option>
									<option value="week" <?php if( old('timeFrame') == 'week' ): ?> selected <?php endif; ?>>周</option>
								</select>
                            </div>
                            <div class="col-xl-2 col-md-3">
                                <label for="direction-select" class="mr-2">方向</label>
								<select class="form-control" name="direction">
									<option value="buy" <?php if( old('direction') == 'buy' ): ?> selected <?php endif; ?>>買入</option>
									<option value="sell" <?php if( old('direction') == 'sell' ): ?> selected <?php endif; ?>>賣出</option>
								</select>
                            </div>
                            <div class="col-xl-2 col-md-3">
                                <label for="exchange-select" class="mr-2">交易所</label>
								<select class="form-control" name="exchange">
									<option value="binance" <?php if( old('exchange') == 'binance' ): ?> selected <?php endif; ?>>Binance</option>
									<option value="ftx" <?php if( old('exchange') == 'ftx' ): ?> selected <?php endif; ?>>FTX</option>
								</select>
                            </div>
                            <div class="col-xl-2 col-md-3">
                                <br>
                                <button type="submit" class="btn btn-blue waves-effect waves-light">搜尋</button>
                            </div>
                            
                        </form>                            
                    </div>
                    <div class="col-lg-4">
                        <div class="text-lg-right">

                        </div>
                    </div><!-- end col-->
                </div>

                <div class="table-responsive">
                    <table class="table table-centered mb-0">
                        <thead class="thead-light">
                            <tr>
                                <th>時間</th>
                                <th>token</th>
                                <th>價格</th>
                                <th>時框</th>
                                <th>方向</th>
								<th>交易所</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sysSignalLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sysSignalLog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($sysSignalLog->created_at); ?>

                                  </td>
                                <td>
                                  <?php echo e($sysSignalLog->token); ?>

                                </td>
                                <td>
                                  <?php echo e($sysSignalLog->price); ?>

                                </td>
                                <td>
                                  <?php echo e($sysSignalLog->timeFrame); ?>

                                </td>
                                <td>
									<?php if( $sysSignalLog->direction == "buy" ): ?>
										買入
									<?php elseif( $sysSignalLog->direction == "sell" ): ?>
										賣出
									<?php endif; ?>
                                </td>
								<td>
									<?php if( $sysSignalLog->exchange == "binance" ): ?>
										Binance
									<?php elseif( $sysSignalLog->exchange == "ftx" ): ?>
										FTX
									<?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="pagination pagination-rounded justify-content-end my-2">
                    <?php echo e($sysSignalLogs->appends(Request::except('page'))->links()); ?>

                </div>

                <style>
                    nav {
                        overflow: scroll !important;
                    }
                </style>
                
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col -->
</div>
<!-- end row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nigripes\resources\views/mge/mge_sysSignalLog.blade.php ENDPATH**/ ?>