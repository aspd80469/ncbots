<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">

            </div>
            <h4 class="page-title">
                參數設定
                &nbsp;&nbsp;&nbsp;
            </h4>
        </div>
    </div>
</div>     
<!-- end page title --> 

<div class="row">

        <div class="col-lg-9">
            <div class="card">
                <div class="card-body">

                    <form class="form-horizontal" role="form" method="POST" enctype="multipart/form-data" action="
                    <?php echo e(URL::to('mge/settings/')); ?>

                    ">
                    <?php echo csrf_field(); ?>

                        <div class="form-group row mb-3">
                            <label for="display" class="col-3 col-form-label">啟用會員註冊<span class="text-danger">*</span></label>
                            <div class="col-9">
                                
                                <select id="allowRegister" name="allowRegister" class="form-control">
                                    <option value="Y" <?php if( $allowRegister == "Y" ): ?> selected <?php endif; ?>>是</option>
                                    <option value="N" <?php if( $allowRegister == "N" ): ?> selected <?php endif; ?>>否</option>
                                </select>
                                                            
                                <?php $__errorArgs = ['allowRegister'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span role="alert" style="color: red;">
                                    <?php echo e($message); ?>

                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row mb-3">
                            <label for="display" class="col-3 col-form-label">會員註冊推薦碼必填<span class="text-danger">*</span></label>
                            <div class="col-9">
                                
                                <select id="requiredRefCode" name="requiredRefCode" class="form-control">
                                    <option value="Y" <?php if( $requiredRefCode == "Y" ): ?> selected <?php endif; ?>>是</option>
                                    <option value="N" <?php if( $requiredRefCode == "N" ): ?> selected <?php endif; ?>>否</option>
                                </select>
                                                            
                                <?php $__errorArgs = ['requiredRefCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span role="alert" style="color: red;">
                                    <?php echo e($message); ?>

                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <div class="form-group row mb-3">
                            <label for="display" class="col-3 col-form-label">啟用TRC20付款</label>
                            <div class="col-9">
                                
                                <select id="allowUserPlanPayByTRC20" name="allowUserPlanPayByTRC20" class="form-control">
                                    <option value="Y" <?php if( $allowUserPlanPayByTRC20 == "Y" ): ?> selected <?php endif; ?>>是</option>
                                    <option value="N" <?php if( $allowUserPlanPayByTRC20 == "N" ): ?> selected <?php endif; ?>>否</option>
                                </select>
                                                            
                                <?php $__errorArgs = ['allowUserPlanPayByTRC20'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span role="alert" style="color: red;">
                                    <?php echo e($message); ?>

                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row mb-3">
                            <label for="display" class="col-3 col-form-label">啟用ERC20付款</label>
                            <div class="col-9">
                                
                                <select id="allowUserPlanPayByERC20" name="allowUserPlanPayByERC20" class="form-control">
                                    <option value="Y" <?php if( $allowUserPlanPayByERC20 == "Y" ): ?> selected <?php endif; ?>>是</option>
                                    <option value="N" <?php if( $allowUserPlanPayByERC20 == "N" ): ?> selected <?php endif; ?>>否</option>
                                </select>
                                                            
                                <?php $__errorArgs = ['allowUserPlanPayByERC20'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span role="alert" style="color: red;">
                                    <?php echo e($message); ?>

                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        <div class="form-group row mb-3">
                            <label for="display" class="col-3 col-form-label">系統主錢包地址(TRC20)</label>
                            <div class="col-9">
                            
                                <input type="text" id="sysMainWalletTRC20" name="sysMainWalletTRC20" class="form-control" placeholder="請輸入TRC20錢包地址" value="<?php if( !is_null($sysMainWalletTRC20) ): ?><?php echo e($sysMainWalletTRC20); ?><?php endif; ?>">
                                
                            </div>
                        </div>

                        <div class="form-group row mb-3">
                            <label for="display" class="col-3 col-form-label">系統主錢包地址(ERC20)</label>
                            <div class="col-9">
                            
                                <input type="text" id="sysMainWalletERC20" name="sysMainWalletERC20" class="form-control" placeholder="請輸入ERC20錢包地址" value="<?php if( !is_null($sysMainWalletERC20) ): ?><?php echo e($sysMainWalletERC20); ?><?php endif; ?>">
                                
                            </div>
                        </div>

                        <div class="form-group mb-0 justify-content-end row">
                            <div class="col-9">
                                <button type="submit" class="btn btn-blue waves-effect waves-light" >儲存</button>
                            </div>
                        </div>
                    </form>

                </div>  <!-- end card-body -->
            </div>  <!-- end card -->
        </div>  <!-- end col -->

    </div>
<!-- end row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nigripes\resources\views/mge/mge_settings.blade.php ENDPATH**/ ?>