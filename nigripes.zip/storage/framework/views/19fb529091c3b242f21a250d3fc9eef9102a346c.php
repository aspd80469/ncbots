<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
            </div>
        </div>
    </div>
</div>
<div class="row justify-content-center">
    <div class="col-xl-10">

        <!-- Pricing Title-->
        <div class="text-center">
            <h3 class="mb-2">選擇 <b>會員方案</b></h3>
            <p class="text-muted w-50 m-auto"></p>
        </div>

        <!-- Plans -->
        <div class="row my-3">

            <?php $__currentLoopData = $userPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userPlan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card card-pricing <?php if( $userPlan->suggest == 1 ): ?> card-pricing-recommended <?php else: ?> card-pricing <?php endif; ?>">
                    <div class="card-body text-center">
                        <p class="card-pricing-plan-name fw-bold text-uppercase"><?php echo e($userPlan->planName); ?></p>
                        <span class="card-pricing-icon <?php if( $userPlan->suggest == 1 ): ?> text-white <?php else: ?> text-dark <?php endif; ?> ">
                            <i class="fas fa-cannabis"></i>
                        </span>
                        <h2 class="card-pricing-price <?php if( $userPlan->suggest == 1 ): ?> text-white <?php endif; ?>">$<?php echo e($userPlan->feeBySeason); ?> <span>/ 季</span></h2>
                        <h3 class="card-pricing-price <?php if( $userPlan->suggest == 1 ): ?> text-white <?php endif; ?>">$<?php echo e($userPlan->feeByYear); ?> <span>/ 年</span></h3>
                        <ul class="card-pricing-features <?php if( $userPlan->suggest == 1 ): ?> text-white <?php else: ?> text-dark <?php endif; ?>">
                            <li>資金上限 <?php echo e(number_format( $userPlan->maxAmount , 0 , '.', ',')); ?> USDT</li>
                            <li>單次下單上限 <?php echo e(number_format( $userPlan->maxOrders , 0 , '.', ',')); ?> USDT</li>
                            <li>機器人數量上限 <?php echo e(number_format( $userPlan->maxBotQty , 0 , '.', ',')); ?> USDT</li>
                            <li>API數量上限  <?php echo e($userPlan->maxApiSlot); ?> 組</li>
                            <li>支援幣安、FTX、ByBit交易所</li>
                        </ul>
                        <button class="btn <?php if( $userPlan->suggest == 1 ): ?> btn-light <?php else: ?> btn-secondary <?php endif; ?>  waves-effect waves-light mt-4 mb-2 width-sm" onclick="window.location='<?php echo e(url("userPlansNewRecord" )); ?>/<?php echo e($userPlan->id); ?>'">選擇此方案</button>
                    </div>
                </div> <!-- end Pricing_card -->
            </div> <!-- end col -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <!-- end row -->

    </div> <!-- end col-->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nigripes\resources\views/userPlans.blade.php ENDPATH**/ ?>