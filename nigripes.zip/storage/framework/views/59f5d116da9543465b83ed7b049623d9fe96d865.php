<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title">
                
            </div>
            <h4 class="page-title">購買會員方案紀錄 &nbsp; &nbsp;
            </h4>
        </div>
    </div>
</div>     
<!-- end page title --> 

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                <div class="table-responsive">
                    <table class="table table-centered mb-0">
                        <thead class="thead-light">
                            <tr>
                                <th>#</th>
								<th>方案</th>
                                <th>起訖日</th>
								<th>實付金額</th>
								<th>付款日期</th>
								<th>類型</th>
								<th>TxID</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $userPlanRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userPlanRecord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                  <?php echo e($userPlanRecord->id); ?>

                                </td>
                                <td>
									<?php echo e($userPlanRecord->st_date); ?> - <?php echo e($userPlanRecord->ed_date); ?>

                                </td>
								<td>
									<?php echo e($userPlanRecord->paidAmount); ?>

                                </td>
								<td>
									<?php echo e($userPlanRecord->paidDay); ?>

                                </td>
								<td>
									<?php echo e($userPlanRecord->type); ?>

                                </td>
								<td>
									<?php echo e($userPlanRecord->TxID); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="pagination pagination-rounded justify-content-end my-2">
                    <?php echo e($userPlanRecords->appends(Request::except('page'))->links()); ?>

                </div>

                <style>
                    nav {
                        overflow: scroll !important;
                    }
                </style>
                
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col -->
</div>
<!-- end row -->
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nigripes\resources\views/userPlanRecords.blade.php ENDPATH**/ ?>