<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title">
                
            </div>
            <h4 class="page-title">
                <?php if( is_null($user) ): ?>
                建立會員
                <?php else: ?>
                編輯會員
                <?php endif; ?>
            </h4>
        </div>
    </div>
</div>     
<!-- end page title --> 
<div class="row">
    <div class="col-lg-6">
        <div class="card-box">
            <div class="card">
                <div class="card-body">

                    <form class="form-horizontal" role="form" method="POST" enctype="multipart/form-data" action="
					<?php if( is_null($user) ): ?>
					<?php echo e(URL::to('mge/user/add')); ?>

					<?php else: ?>
					<?php echo e(URL::to('mge/user')); ?>/<?php echo e($user->id); ?>

					<?php endif; ?>
					">
					<?php echo csrf_field(); ?>
					
						<div class="mb-3">
                            <label for="email" class="form-label">Email</label>
							<?php if( is_null($user) ): ?>
							
								<input type="text" id="email" name="email" class="form-control" placeholder="請輸入Email" value="">
								
								<?php if( $errors->has('email') ): ?>
								<span class="help-block" style="color: red;">
								<strong>必填</strong>
								</span>
								<?php endif; ?>
								
							<?php else: ?>
							<label for="email" class="form-control">
                                <?php echo e($user->email); ?>

                            </label>
								
							
							<?php endif; ?>
                        </div>

                        <div class="mb-3">
                            <label for="name" class="form-label">姓名</label>
                            <input type="text" id="name" name="name" class="form-control" placeholder="請輸入姓名" value="<?php if( !is_null($user) ): ?><?php echo e($user->name); ?><?php endif; ?>">
							
							<?php if( $errors->has('name') ): ?>
                                <span class="help-block" style="color: red;">
                                <strong>必填，最大長度為20字元</strong>
                                </span>
							<?php endif; ?>
					
                        </div>
						
                        <div class="mb-3">
                            <label for="password" class="form-label">密碼<span class="text-danger">*</span></label>
                            <input type="text" id="password" name="password" class="form-control" placeholder="請輸入密碼<?php if( !is_null($user) ): ?>，無變更請留空<?php else: ?> 最少6個字元  <?php endif; ?>" >

                            <?php if( !is_null($user) ): ?>
                            <button type="button"" class="btn btn-danger waves-effect" onclick="window.location='<?php echo e(url("mge/userPwdReset/" )); ?>/<?php echo e($user->id); ?>'">重置</button>
                            <?php endif; ?>

                        </div>
						
						<div class="mb-3">
                            <label for="notice" class="form-label">備註</label>
                            <textarea class="form-control" name="notice" ><?php if( !is_null($user) ): ?><?php echo e($user->notice); ?><?php endif; ?></textarea>
					
                        </div>

                        <?php if( !is_null($user) ): ?>
                        <div class="mb-3">
                            <label for="burnMoney" class="form-label">燃料費</label>
                            <label for="burnMoney" class="form-control">
                                <?php echo e($user->burnMoney); ?>

                            </label>
                            
                            <button type="button"" class="btn btn-secondary waves-effect" onclick="window.location='<?php echo e(url("mge/userBurnMoney/" )); ?>/<?php echo e($user->id); ?>'" >異動</button>
                        </div>
                        <?php endif; ?>

						<div class="mb-3">
                            <label for="tgId" class="form-label">Telegram ID</label>
                            <input type="text" id="tgId" name="tgId" class="form-control" maxlength="20" placeholder="請輸入Telegram ID" value="<?php if( !is_null($user) ): ?><?php echo e($user->tgId); ?><?php endif; ?>">
							
							<?php if( $errors->has('tgId') ): ?>
                                <span class="help-block" style="color: red;">
                                <strong>必填，最大長度為20字元</strong>
                                </span>
							<?php endif; ?>
					
                        </div>
						
						<div class="mb-3">
                            <label for="status" class="form-label">狀態</label>
							<select class="form-control" name="status">
								<option value="0" <?php if( !is_null($user) && $user->status == '0' ): ?> selected <?php endif; ?>>啟用</option>
								<option value="1" <?php if( !is_null($user) && $user->status == '1' ): ?> selected <?php endif; ?>>停用</option>
							</select>
							<?php if( $errors->has('status') ): ?>
							<span class="help-block" style="color: red;">
							<strong>必填，必須選擇一個選項</strong>
							</span>
							<?php endif; ?>
					
                        </div>

                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-blue waves-effect waves-light">儲存</button>
                            <button type="button"" class="btn btn-secondary waves-effect" onclick="window.location='<?php echo e(url("mge/users" )); ?>'">返回</button>
							
							<?php if( !is_null($user) ): ?>
							<a href="<?php echo e(url("mge/user/delete/" . $user->id )); ?>" onclick="javascript:return confirm('確認刪除會員?');" class="btn btn-danger waves-effect">刪除</a>
							<?php endif; ?>
				
                        </div>
                        
                    </form>
                </div> <!-- end card-body -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nigripes\resources\views/mge/mge_user_single.blade.php ENDPATH**/ ?>