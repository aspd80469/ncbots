<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
            </div>
            <h4 class="page-title">
                我的機器人<?php if( !is_null($actUserPlan) ): ?>(<?php echo e(count($myBots)); ?>/<?php echo e($actUserPlan->getUserPlan->maxBotQty); ?>)<?php endif; ?>
                <?php if( !is_null($actUserPlan) && count($myBots) < $actUserPlan->getUserPlan->maxBotQty): ?>
                <button type="button" class="btn btn-blue waves-effect waves-light" onclick="window.location='<?php echo e(url('/myBots/0')); ?>'"><i class="fas fa-plus"></i> 新增機器人</button>
                <?php endif; ?>
            </h4>
            
        </div>
    </div>
</div>

<div class="row">

    <?php $__currentLoopData = $myBots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myBot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-4">
        <div class="card border-dark border mb-3">
            <div class="card-header">
                <a href="<?php echo e(url('/myBots/')); ?>/<?php echo e($myBot->id); ?>" >
                    #<?php echo e($myBot->id); ?>機器人
                </a>
                <a href="<?php echo e(url('/myBotOrders/')); ?>/<?php echo e($myBot->id); ?>" >
                    下單紀錄
                </a>
                <span role="alert" style="color: red;">
                    <?php echo e($myBot->botMsg); ?>

                </span>
            </div>
            <div class="card-body">
                <h4 class="card-title text-success">
                    <?php if( $myBot->status == 0 ): ?>
                    正常(運行中)
                    <?php elseif( $myBot->status == 1 ): ?>
                    暫停中
                    <?php elseif( $myBot->status ==2 ): ?>
                    終止
                    <?php endif; ?>
                </h4>
                <h4 class="text-dark my-1"><?php echo e($myBot->getBotStgy->stgyName); ?></h4>
                持倉資訊
                <textarea class="form-control" id="field_1" name="field_1" rows="10"><?php print_R($myBot->field_1); ?></textarea>
                追蹤中買入幣種
                <textarea class="form-control" id="field_2" name="field_2" rows="10"><?php print_R($myBot->field_2); ?></textarea>
                追蹤中賣出幣種
                <textarea class="form-control" id="field_3" name="field_3" rows="10"><?php print_R($myBot->field_3); ?></textarea>

                <a href="<?php echo e(url('/myBotOrders/')); ?>/<?php echo e($myBot->id); ?>" >
                <h3 class="text-dark my-1 text-end">投資金額 $<span data-plugin="counterup"><?php echo e(number_format( $myBot->invAmount , 0 , '.', ',')); ?></span></h3>
                </a>
            </div>
        </div>
    </div>
    <!-- end col -->

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script language="javascript">
        setTimeout(function(){
            window.location.reload(1);
        }, 30000);
    </script>


    

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nigripes\resources\views/myBots.blade.php ENDPATH**/ ?>