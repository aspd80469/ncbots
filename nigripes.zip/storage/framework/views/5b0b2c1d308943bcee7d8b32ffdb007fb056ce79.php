<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title">
                
            </div>
            <h4 class="page-title">會員下單紀錄 &nbsp; &nbsp;
            </h4>
        </div>
    </div>
</div>     
<!-- end page title --> 

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="row g-13">
                    <div class="col-lg-12">
                        <form class="row g-3" role="form" method="POST" enctype="multipart/form-data" action="<?php echo e(url('mge/orders')); ?>">
                            
                            
                        </form>                            
                    </div>
                    <div class="col-lg-4">
                        <div class="text-lg-right">

                        </div>
                    </div><!-- end col-->
                </div>

                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>機器人ID</th>
								<th>幣種</th>
                                
                                <th>執行狀態</th>
                                
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($order->id); ?></th>
                                <th ><?php echo e($order->myBotId); ?></th>
                                <th ><?php echo e($order->symbol); ?></th>
                                <th >
                                    <?php if( $order->isTrade == 0 ): ?>
                                    執行中
                                    <?php else: ?>
                                    已完成	
                                    <?php endif; ?>
                                </th>
                            </tr>
                            <tr>
                                <td colspan="4">
                                    
                                    <table class="table mb-0">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>機器人ID</th>
                                                <th>幣種</th>
                                                <th>數量</th>
                                                <th>時框</th>
                                                <th>方向</th>
                                                <th>交易所</th>
                                                <th>時間</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $order->getorderLog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $olog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($olog->id); ?></th>
                                                <td><?php echo e($olog->myBotId); ?></td>
                                                <td><?php echo e($olog->symbol); ?></td>
                                                <td><?php echo e($olog->qty); ?></td>
                                                <td>
                                                    <?php if( $olog->timeFrame == "15m" ): ?>
                                                    15M
                                                    <?php elseif( $olog->timeFrame == "30m" ): ?>
                                                        30M
                                                    <?php elseif( $olog->timeFrame == "1h" ): ?>
                                                        1H
                                                    <?php elseif( $olog->timeFrame == "2h" ): ?>
                                                        2H
                                                    <?php elseif( $olog->timeFrame == "4h" ): ?>
                                                        4H
                                                    <?php elseif( $olog->timeFrame == "6h" ): ?>
                                                        6H
                                                    <?php elseif( $olog->timeFrame == "12h" ): ?>
                                                        12H
                                                    <?php elseif( $olog->timeFrame == "day" ): ?>
                                                        天
                                                    <?php elseif( $olog->timeFrame == "week" ): ?>
                                                        周
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if( $olog->direction == "buy" ): ?>
                                                    買入
                                                    <?php else: ?>
                                                    賣出	
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if( $olog->exchange == "binance" ): ?>
                                                        Binance
                                                    <?php elseif( $olog->exchange == "ftx" ): ?>
                                                        FTX
                                                    <?php elseif( $olog->exchange == "bybit" ): ?>
                                                        Bybit
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($olog->created_at); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
                <div class="pagination pagination-rounded justify-content-end my-2">
                    <?php echo e($orders->appends(Request::except('page'))->links()); ?>

                </div>

                <style>
                    nav {
                        overflow: scroll !important;
                    }
                </style>
                
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col -->
</div>
<!-- end row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nigripes\resources\views/mge/mge_ordersByUser.blade.php ENDPATH**/ ?>