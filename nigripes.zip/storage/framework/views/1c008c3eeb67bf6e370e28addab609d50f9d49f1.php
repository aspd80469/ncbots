<?php $__env->startSection('content'); ?>

<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title">
                
            </div>
            <h4 class="page-title">會員下單 &nbsp; &nbsp;
            </h4>
        </div>
    </div>
</div>     
<!-- end page title --> 

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="row g-13">
                    <div class="col-lg-12">
                        <form class="row g-3" role="form" method="POST" enctype="multipart/form-data" action="<?php echo e(url('mge/orders')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="col-xl-2 col-md-3">
                                <label for="status-select" class="mr-2">Email</label>
                                <input type="text" class="form-control" id="s_email" name="s_email" value="<?php echo e(old('s_email')); ?>" placeholder="">
                            </div>
                            <div class="col-xl-2 col-md-3">
                                <label for="status-select" class="mr-2">備註</label>
                                <input type="text" class="form-control"  id="s_notice" name="s_notice" value="<?php echo e(old('s_notice')); ?>">
                            </div>
                            <div class="col-xl-2 col-md-3">
                                <br>
                                <button type="submit" class="btn btn-blue waves-effect waves-light">搜尋</button>
                            </div>
                            
                        </form>                            
                    </div>
                    <div class="col-lg-4">
                        <div class="text-lg-right">

                        </div>
                    </div><!-- end col-->
                </div>

                <div class="table-responsive">
                    <table class="table table-centered mb-0">
                        <thead class="thead-light">
                            <tr>
                                <th>下單紀錄</th>
                                <th>Email</th>
                                <th>姓名</th>
                                <th>燃料費</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(url("mge/orders/" . $user->id )); ?>" class="font-weight-bold">
                                        檢視下單紀錄
                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(url('mge/orders/' . $user->id )); ?>" class="font-weight-bold">
                                        <?php echo e($user->email); ?>

                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(url("mge/user/" . $user->id )); ?>" class="font-weight-bold">
                                        <?php echo e($user->name); ?>

                                    </a>
                                </td>
                                <td>
                                    <?php echo e($user->burnMoney); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="pagination pagination-rounded justify-content-end my-2">
                    <?php echo e($users->appends(Request::except('page'))->links()); ?>

                </div>

                <style>
                    nav {
                        overflow: scroll !important;
                    }
                </style>
                
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col -->
</div>
<!-- end row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nigripes\resources\views/mge/mge_orders.blade.php ENDPATH**/ ?>