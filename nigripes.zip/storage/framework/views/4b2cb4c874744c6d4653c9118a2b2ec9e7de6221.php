<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title">
                
            </div>
            <h4 class="page-title">
                管理機器人設定
            </h4>
        </div>
    </div>
</div>     
<!-- end page title --> 
<div class="row">
    <div class="col-lg-6">
        <div class="card-box">
            <div class="card">
                <div class="card-body">

                    <form class="form-horizontal" role="form" method="POST" enctype="multipart/form-data" action="
					<?php if( is_null($myBot) ): ?>
                    <?php echo e(URL::to('myBots/add')); ?>

                    <?php else: ?>
                    <?php echo e(URL::to('myBots/')); ?>/<?php echo e($myBot->id); ?>

                    <?php endif; ?>
					">
					<?php echo csrf_field(); ?>
					
                        <div class="mb-3">
                            <label for="invAmount" class="form-label">投資金額</label>
                            <input type="number" id="invAmount" name="invAmount" class="form-control" placeholder="請輸入投資金額" min="0" required>
							
							<?php if( $errors->has('invAmount') ): ?>
                                <span class="help-block" style="color: red;">
                                <strong>必填，請輸入投資金額</strong>
                                </span>
							<?php endif; ?>
					
                        </div>

                        <div class="mb-3">
                            <label for="usedStgy" class="form-label">使用策略</label>
							
                            <select id="usedStgy" name="usedStgy" class="form-control">
                                <option value="">---請選擇---</option>
                                <?php $__currentLoopData = $botsStgys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $botsStgy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($botsStgy->id); ?>" <?php if(!is_null($myBot) && $myBot->usedStgy == $botsStgy->id ): ?> selected <?php endif; ?>><?php echo e($botsStgy->stgyName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                                                        
                            <?php $__errorArgs = ['display'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span role="alert" style="color: red;">
                                <?php echo e($message); ?>

                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					
                        </div>

                        <div class="mb-3">
                            <label for="apiKeyId1" class="form-label">API Key 1</label>
							
                            <select id="apiKeyId1" name="apiKeyId1" class="form-control" required>
                                <option value="">---請選擇---</option>
                                <?php $__currentLoopData = $userKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userKey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($userKey->id); ?>" <?php if(!is_null($myBot) && $myBot->apiKeyId1 == $userKey->id ): ?> selected <?php endif; ?>><?php echo e($userKey->exchange); ?> - <?php echo e($userKey->apikey); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                                                        
                            <?php $__errorArgs = ['apiKeyId1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span role="alert" style="color: red;">
                                <?php echo e($message); ?>

                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					
                        </div>

                        <div class="mb-3">
                            <label for="apiKeyId2" class="form-label">API Key 2</label>
							
                            <select id="apiKeyId2" name="apiKeyId2" class="form-control">
                                <option value="">---請選擇---</option>
                                <?php $__currentLoopData = $userKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userKey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($userKey->id); ?>" <?php if(!is_null($myBot) && $myBot->apiKeyId2 == $userKey->id ): ?> selected <?php endif; ?>><?php echo e($userKey->exchange); ?> - <?php echo e($userKey->apikey); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                                                        
                            <?php $__errorArgs = ['apiKeyId2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span role="alert" style="color: red;">
                                <?php echo e($message); ?>

                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					
                        </div>

                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-blue waves-effect waves-light">儲存</button>
                            <button type="button"" class="btn btn-secondary waves-effect" onclick="window.location='<?php echo e(url("myBots" )); ?>'">返回</button>			
                        </div>
                        
                    </form>
                </div> <!-- end card-body -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\nigripes\resources\views/myBots_single.blade.php ENDPATH**/ ?>